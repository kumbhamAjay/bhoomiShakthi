import React, { useState } from 'react';
import { Phone } from 'lucide-react';
import toast from 'react-hot-toast';

export default function LoginForm() {
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);

  const handleSendOTP = (e) => {
    e.preventDefault();
    // Simulate OTP sending
    toast.success('OTP sent successfully!');
    setOtpSent(true);
  };

  const handleVerifyOTP = (e) => {
    e.preventDefault();
    // Simulate OTP verification
    toast.success('Login successful!');
  };

  return (
    <div className="w-full max-w-md">
      <form onSubmit={otpSent ? handleVerifyOTP : handleSendOTP} className="bg-white shadow-lg rounded-lg px-8 pt-6 pb-8 mb-4">
        <div className="flex items-center justify-center mb-6">
          <Phone className="w-12 h-12 text-green-600" />
        </div>
        <h2 className="text-2xl font-bold text-center mb-6">Login to Your Account</h2>
        
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="phone">
            Phone Number
          </label>
          <input
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            id="phone"
            type="tel"
            placeholder="Enter your phone number"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            disabled={otpSent}
          />
        </div>

        {otpSent && (
          <div className="mb-6">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="otp">
              Enter OTP
            </label>
            <input
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 mb-3 leading-tight focus:outline-none focus:shadow-outline"
              id="otp"
              type="text"
              placeholder="Enter OTP"
              value={otp}
              onChange={(e) => setOtp(e.target.value)}
            />
          </div>
        )}

        <div className="flex items-center justify-center">
          <button
            className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline w-full"
            type="submit"
          >
            {otpSent ? 'Verify OTP' : 'Send OTP'}
          </button>
        </div>
      </form>
    </div>
  );
}
